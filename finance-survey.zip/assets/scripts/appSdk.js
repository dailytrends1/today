import {
    setUrlSearchParam
} from "./shared-YO72XYLM.js";
import "./shared-CRXPGHIL.js";
var _a;
if (typeof window !== "undefined") {
    window.app = Object.assign((_a = window.app) != null ? _a : {}, {
        setUrlSearchParam
    });
}